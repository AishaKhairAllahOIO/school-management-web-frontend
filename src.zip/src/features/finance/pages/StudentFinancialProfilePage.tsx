import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, GraduationCap, Printer } from "lucide-react";
import { Navigate, useNavigate, useParams } from "react-router-dom";

import { Button } from "@/shared/ui/button";
import { studentApi } from "../../users/students/api/student.api";
import { studentKeys } from "../../users/students/hooks/student.keys";
import { useStudentFinancialAccount } from "../hooks/useFinancialAccounts";
import { ContractsSection } from "../components/contracts/ContractsSection";
import { InstallmentsSection } from "../components/installments/InstallmentsSection";
import { CashierSection } from "../components/cashier/CashierSection";
import { FinanceTableSkeleton } from "../components/shared/FinanceTableSkeleton";
import { FullFinancialStatementDialog } from "../components/cashier/FullFinancialStatementDialog";
import { useState } from "react";

function isNotFound(error: unknown) {
  return (error as { response?: { status?: number } })?.response?.status === 404;
}

export function StudentFinancialProfilePage() {
  const { studentId } = useParams<{ studentId: string }>();
  const navigate = useNavigate();
  const [statementOpen, setStatementOpen] = useState(false);

  const studentQuery = useQuery({
    queryKey: studentId ? studentKeys.detail(studentId) : ["student-details", "missing"],
    queryFn: () => studentApi.getDetails(studentId!),
    enabled: Boolean(studentId),
    retry: false,
  });

  const accountQuery = useStudentFinancialAccount(studentId, Boolean(studentId));

  if (!studentId) return <Navigate to="/finance/students" replace />;

  if (studentQuery.isLoading || accountQuery.isLoading) {
    return (
      <div className="pt-6">
        <FinanceTableSkeleton />
      </div>
    );
  }

  const student = studentQuery.data?.student;
  const account = isNotFound(accountQuery.error) ? undefined : accountQuery.data;

  if (studentQuery.isError || !student || (accountQuery.isError && !isNotFound(accountQuery.error))) {
    return (
      <div className="mt-6 rounded-[20px] border border-destructive/20 bg-destructive/[0.035] p-8 text-center">
        <h2 className="text-[15px] font-medium text-foreground/88">
          Student financial profile unavailable
        </h2>
        <p className="mt-2 text-[12.5px] text-muted-foreground">
          The student or financial account could not be loaded. Please return to the accounts list and try again.
        </p>
        <Button variant="outline" className="mt-4" onClick={() => navigate("/finance/students")}>
          Back to student accounts
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-5 pt-4 sm:pt-5 lg:pt-6">
      <section className="rounded-[22px] border border-border/50 bg-card p-4 shadow-[0_10px_32px_rgba(31,22,73,0.04)] sm:p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex min-w-0 items-center gap-3">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-[15px] border border-primary/12 bg-primary/[0.065] text-primary">
              <GraduationCap className="h-5 w-5" strokeWidth={1.8} />
            </span>
            <div className="min-w-0">
              <p className="text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground/70">
                Student financial profile
              </p>
              <h1 className="truncate text-[18px] font-medium text-foreground/90">
                {student.fullName}
              </h1>
              <p className="mt-0.5 text-[12px] text-muted-foreground/75">
                {account
                  ? Number(account.remainingBalance) <= 0
                    ? "Financial account fully paid"
                    : "Active financial account"
                  : "Financial contract not configured yet"}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {account && Number(account.remainingBalance) <= 0 ? (
              <Button
                variant="outline"
                className="rounded-xl border-success/20 text-success hover:bg-success/[0.05]"
                onClick={() => setStatementOpen(true)}
              >
                <Printer className="mr-2 h-4 w-4" /> Print complete statement
              </Button>
            ) : null}
            <Button variant="outline" className="rounded-xl" onClick={() => navigate("/finance/students")}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Student accounts
            </Button>
          </div>
        </div>
      </section>

      <ContractsSection
        studentId={studentId}
        title="Contract & Account Summary"
        description={
          account
            ? "Review this student's financial agreement and current balance. Contract editing remains available only while the backend allows it."
            : "Create this student's financial agreement from the fee plans, installment policies, and extra services configured in Financial Settings."
        }
        showCreateAction={!account}
        showViewAction={Boolean(account)}
      />

      {account ? (
        <>
          <InstallmentsSection
            studentId={studentId}
            installments={account.installments}
            title="Installment Schedule"
            description="Review the installments generated by the student's selected financial policy."
          />

          <CashierSection
            studentId={studentId}
            accountId={account.id}
            studentName={student.fullName}
            title="Payment History"
            description="Record, review, update, delete, and print payment receipts for this student account."
            canProcessPayment={Number(account.remainingBalance) > 0}
          />
        </>
      ) : (
        <section className="rounded-[20px] border border-dashed border-border/55 bg-card px-6 py-10 text-center">
          <h3 className="text-[14px] font-medium text-foreground/85">
            Installments and payments will appear after contract creation
          </h3>
          <p className="mx-auto mt-1.5 max-w-xl text-[12.5px] leading-5 text-muted-foreground/75">
            The installment schedule is generated from the selected policy. Payments can be recorded after the financial account is configured.
          </p>
        </section>
      )}

      {account ? (
        <FullFinancialStatementDialog
          open={statementOpen}
          onOpenChange={setStatementOpen}
          studentName={student.fullName}
          academicYearName={account.academicYearName}
          account={account}
        />
      ) : null}
    </div>
  );
}
