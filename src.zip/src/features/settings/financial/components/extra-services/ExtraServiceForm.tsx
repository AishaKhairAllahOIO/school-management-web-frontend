import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus } from "lucide-react";

import { Button } from "@/shared/ui/button";
import { Input } from "@/shared/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/shared/ui/select";

import {
  extraServiceSchema,
  type ExtraServiceFormValues,
} from "../../schemas/extraService.schema";

type Props = {
  defaultValues?: Partial<ExtraServiceFormValues>;
  feePlans: { id: number; name: string }[];
  isLoading?: boolean;
  onSubmit: (values: ExtraServiceFormValues) => void;
};

export function ExtraServiceForm({
  defaultValues,
  feePlans,
  onSubmit,
  isLoading = false,
}: Props) {

  const {
    control,
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(extraServiceSchema),
    defaultValues: {
      feePlanId: defaultValues?.feePlanId ?? 0,
      type: defaultValues?.type ?? "other",
      name: defaultValues?.name ?? "",
      amount: defaultValues?.amount ?? 0,
    },
  });

  return (
    <form onSubmit={handleSubmit((data) => onSubmit(data as ExtraServiceFormValues))} className="space-y-6">
      <div className="space-y-2">
        <label className="text-[15px] font-medium text-foreground">Fee Plan</label>
        <Controller
          control={control}
          name="feePlanId"
          render={({ field }) => (
            <Select
              value={field.value ? String(field.value) : ""}
              onValueChange={(value) => field.onChange(Number(value))}
            >
              <SelectTrigger className="h-11 w-full rounded-xl border-border/70 bg-background">
                <SelectValue placeholder="Select fee plan" />
              </SelectTrigger>
              <SelectContent>
                {feePlans.map((plan) => (
                  <SelectItem key={plan.id} value={String(plan.id)}>
                    {plan.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        />
        {errors.feePlanId && (
          <p className="text-[15px] text-red-500">{String(errors.feePlanId.message)}</p>
        )}
      </div>

      <div className="space-y-2">
        <label className="text-[15px] font-medium text-foreground">Type</label>
        <Controller
          control={control}
          name="type"
          render={({ field }) => (
            <Select value={String(field.value)} onValueChange={field.onChange}>
              <SelectTrigger className="h-11 w-full rounded-xl border-border/70 bg-background">
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                {(
                  ["uniform", "books", "activities", "insurance", "other"] as const
                ).map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        />
        {errors.type && (
          <p className="text-[15px] text-red-500">{String(errors.type.message)}</p>
        )}
      </div>

      <div className="space-y-2">
        <label className="text-[15px] font-medium text-foreground">
          Service Name
        </label>
        <Input
          placeholder="Uniform"
          className="h-11 rounded-xl border-border/70 bg-background"
          {...register("name")}
        />
        {errors.name && (
          <p className="text-[15px] text-red-500">{String(errors.name.message)}</p>
        )}
      </div>

      <div className="space-y-2">
        <label className="text-[15px] font-medium text-foreground">Amount</label>
        <Input
          type="number"
          min={0}
          step={1}
          className="h-11 rounded-xl border-border/70 bg-background"
          {...register("amount")}
        />
        {errors.amount && (
          <p className="text-[15px] text-red-500">{String(errors.amount.message)}</p>
        )}
      </div>

      <Button
        type="submit"
        disabled={isLoading}
        className="h-12 w-full rounded-2xl bg-violet-600 text-white shadow-sm hover:bg-violet-700"
      >
        {isLoading ? (
          "Saving..."
        ) : (
          <>
            <Plus className="mr-2 h-4 w-4" /> Save Service
          </>
        )}
      </Button>
    </form>
  );
}