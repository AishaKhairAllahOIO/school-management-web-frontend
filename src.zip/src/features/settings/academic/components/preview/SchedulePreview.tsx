import {
  BookOpen,
  Coffee,
  Flag,
} from "lucide-react";

import type { SchoolScheduleSettings } from "../../types/academic-settings.types";
import { buildSchedulePreview } from "../../utils/academic-settings.utils";

type SchedulePreviewProps = {
  schedule: SchoolScheduleSettings;
};

export function SchedulePreview({
  schedule,
}: SchedulePreviewProps) {
  const { items, endTime } =
    buildSchedulePreview(schedule);

  if (items.length === 0) {
    return (
      <div className="rounded-[14px] border border-dashed border-border/70 bg-muted/[0.12] p-5 text-center">
        <p className="text-[14px] font-medium text-foreground">
          No working days selected
        </p>

        <p className="mt-1 text-[12px] leading-5 text-muted-foreground">
          Select at least one working day to build the preview.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {items.map((item, index) => {
        const isBreak = item.type === "break";

        return (
          <div
            key={`${item.type}-${item.time}-${index}`}
            className={[
              "flex items-center justify-between",
              "gap-3 rounded-[13px]",
              "border px-3 py-2.5",
              isBreak
                ? "border-amber-200/55 bg-amber-50/55"
                : "border-border/55 bg-background",
            ].join(" ")}
          >
            <div className="flex min-w-0 items-center gap-2.5">
              <span
                className={[
                  "flex h-7 w-7 shrink-0",
                  "items-center justify-center",
                  "rounded-[9px]",
                  isBreak
                    ? "bg-amber-100 text-amber-600"
                    : "bg-primary/[0.07] text-primary",
                ].join(" ")}
              >
                {isBreak ? (
                  <Coffee size={13} strokeWidth={1.8} />
                ) : (
                  <BookOpen size={13} strokeWidth={1.8} />
                )}
              </span>

              <span className="truncate text-[13px] font-medium text-foreground">
                {item.label}
              </span>
            </div>

            <span className="shrink-0 text-[13px] font-medium text-muted-foreground">
              {item.time}
            </span>
          </div>
        );
      })}

      <div className="flex items-center justify-between rounded-[13px] bg-primary px-3 py-2.5 text-primary-foreground shadow-sm">
        <div className="flex items-center gap-2.5">
          <Flag size={14} strokeWidth={1.8} />
          <span className="text-[13px] font-medium">End of Day</span>
        </div>

        <span className="text-[13px] font-medium">{endTime}</span>
      </div>
    </div>
  );
}
