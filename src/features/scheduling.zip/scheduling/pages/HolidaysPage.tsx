import {
  Download,
  Edit3,
  Palmtree,
  Plus,
  Printer,
  Sparkles,
  Trash2,
} from "lucide-react";
import { useState } from "react";

import {
  PrintPreviewDialog,
  createPosterDocument,
  usePrintIdentity,
  usePrintPreview,
} from "@/features/printing";
import { exportScheduleWorkbook } from "@/features/scheduling/shared/utils/export-schedule-xlsx";
import { ConfirmDelete, Editor, Input, SelectField } from "./ExamSchedulesPage";

type Holiday = {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  type: string;
};

const initial: Holiday[] = [
  {
    id: "h-1",
    name: "New Year Holiday",
    startDate: "2027-01-01",
    endDate: "2027-01-01",
    type: "Public Holiday",
  },
  {
    id: "h-2",
    name: "Midyear Break",
    startDate: "2027-01-24",
    endDate: "2027-02-04",
    type: "School Break",
  },
  {
    id: "h-3",
    name: "Teachers Development Day",
    startDate: "2027-03-11",
    endDate: "2027-03-11",
    type: "School Event",
  },
];

function formatHolidayDate(value: string) {
  const date = new Date(`${value}T00:00:00`);
  return Number.isNaN(date.getTime())
    ? value
    : new Intl.DateTimeFormat(undefined, {
        year: "numeric",
        month: "long",
        day: "2-digit",
      }).format(date);
}

export function HolidaysPage() {
  const [items, setItems] = useState(initial);
  const [editing, setEditing] = useState<Holiday | null>(null);
  const [form, setForm] = useState<Omit<Holiday, "id"> | null>(null);
  const [deleting, setDeleting] = useState<Holiday | null>(null);
  const printPreview = usePrintPreview();
  const printIdentity = usePrintIdentity();

  function save() {
    if (!form?.name.trim() || !form.startDate || !form.endDate) return;
    if (editing) {
      setItems((current) =>
        current.map((item) =>
          item.id === editing.id ? { ...editing, ...form } : item,
        ),
      );
    } else {
      setItems((current) => [
        ...current,
        { ...form, id: `holiday-${Date.now()}` },
      ]);
    }
    setForm(null);
    setEditing(null);
  }

  function exportHolidays() {
    exportScheduleWorkbook({
      fileName: "school-holidays",
      sheetName: "Holidays",
      rows: items.map((item) => ({
        Holiday: item.name,
        "Start Date": item.startDate,
        "End Date": item.endDate,
        Type: item.type,
      })),
    });
  }

  function printHolidayPoster(item: Holiday) {
    printPreview.openPreview(
      createPosterDocument({
        title: `${item.name} poster`,
        identity: printIdentity,
        eyebrow: item.type,
        headline: item.name,
        description:
          "Please note this date and plan school activities accordingly.",
        details: [
          { label: "Starts", value: formatHolidayDate(item.startDate) },
          { label: "Ends", value: formatHolidayDate(item.endDate) },
          {
            label: "Duration",
            value:
              item.startDate === item.endDate
                ? "One day"
                : "School calendar period",
          },
        ],
        footer: "Rest · Recharge · Return ready",
        tone: "sunset",
      }),
    );
  }

  return (
    <div className="space-y-4">
      <section className="flex justify-end gap-2 rounded-[22px] border border-border/45 bg-card p-4">
        <button
          type="button"
          onClick={exportHolidays}
          className="inline-flex h-9 items-center gap-2 rounded-full border border-border/65 px-4 text-[12px]"
        >
          <Download size={14} /> Export
        </button>
        <button
          type="button"
          onClick={() => {
            setEditing(null);
            setForm({
              name: "",
              startDate: "",
              endDate: "",
              type: "Public Holiday",
            });
          }}
          className="inline-flex h-9 items-center gap-2 rounded-full bg-primary px-4 text-[12px] text-primary-foreground"
        >
          <Plus size={14} /> Add Holiday
        </button>
      </section>

      <section className="grid gap-3 md:grid-cols-3">
        {items.map((item, index) => {
          const Icon = index === 1 ? Palmtree : Sparkles;
          const tone = [
            "border-amber-200/60 bg-amber-50/65 text-amber-700",
            "border-sky-200/60 bg-sky-50/65 text-sky-700",
            "border-violet-200/60 bg-violet-50/65 text-violet-700",
          ][index % 3];

          return (
            <article key={item.id} className={`rounded-[22px] border p-4 ${tone}`}>
              <span className="flex h-10 w-10 items-center justify-center rounded-[14px] bg-card/70">
                <Icon size={18} />
              </span>
              <p className="mt-4 text-[14px] font-medium text-foreground">{item.name}</p>
              <p className="mt-1 text-[11px] text-muted-foreground">{item.type}</p>
              <p className="mt-3 text-[12px] font-medium">
                {item.startDate} → {item.endDate}
              </p>
              <div className="mt-4 flex flex-wrap justify-end gap-2 border-t border-current/10 pt-3">
                <button
                  type="button"
                  onClick={() => printHolidayPoster(item)}
                  className="inline-flex h-8 items-center gap-1.5 rounded-full bg-card/75 px-3 text-[11px]"
                >
                  <Printer size={12} /> Poster
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEditing(item);
                    setForm({ ...item });
                  }}
                  className="inline-flex h-8 items-center gap-1.5 rounded-full bg-card/75 px-3 text-[11px]"
                >
                  <Edit3 size={12} /> Edit
                </button>
                <button
                  type="button"
                  onClick={() => setDeleting(item)}
                  className="inline-flex h-8 items-center gap-1.5 rounded-full bg-rose-50 px-3 text-[11px] text-rose-600"
                >
                  <Trash2 size={12} /> Delete
                </button>
              </div>
            </article>
          );
        })}
      </section>

      {form ? (
        <Editor
          title={editing ? "Edit Holiday" : "Add Holiday"}
          onClose={() => setForm(null)}
          onSave={save}
        >
          <Input
            label="Holiday Name"
            value={form.name}
            onChange={(value) => setForm({ ...form, name: value })}
          />
          <SelectField
            label="Type"
            value={form.type}
            onChange={(value) => setForm({ ...form, type: value })}
            options={["Public Holiday", "School Break", "School Event"].map(
              (value) => ({ value, label: value }),
            )}
          />
          <Input
            label="Start Date"
            type="date"
            value={form.startDate}
            onChange={(value) => setForm({ ...form, startDate: value })}
          />
          <Input
            label="End Date"
            type="date"
            value={form.endDate}
            onChange={(value) => setForm({ ...form, endDate: value })}
          />
        </Editor>
      ) : null}

      {deleting ? (
        <ConfirmDelete
          title="Delete holiday?"
          description={`${deleting.name} will be removed from the school calendar.`}
          onClose={() => setDeleting(null)}
          onConfirm={() => {
            setItems((current) => current.filter((item) => item.id !== deleting.id));
            setDeleting(null);
          }}
        />
      ) : null}

      <PrintPreviewDialog
        open={printPreview.isOpen}
        onOpenChange={printPreview.setOpen}
        document={printPreview.document}
      />
    </div>
  );
}
